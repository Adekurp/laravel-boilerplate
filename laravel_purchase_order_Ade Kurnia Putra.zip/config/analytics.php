<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Google Analytics
    |--------------------------------------------------------------------------
    |
    | Found in views/partials/ga.blade.php
    */
    'google-analytics' => 'UA-XXXXX-X',
];
