<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\Maxy\laravel-boilerplate\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>