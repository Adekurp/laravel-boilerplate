(function ($) {
    $('.select2').select2();
})(jQuery);