---
name: Bring me a Feature
about: Suggest and Pull a new feature, which is adding great value for the Laravel Boilerplate users.
title: Bring me a Feature - YOUR-FEATURE-SUGGESTION
labels: 'enhancement'
assignees: ''
---
### Feature request
- _TBD_

### Links / Documentation / etc.
- _TBD_

**Footnote:**
In the case of `unique->tested->accepted` feature we'll be happy to include your GitHub handle to the list of contributors on the main Laravel Boilerplate page; see also [README.md / Contributors and Supporters](https://github.com/Labs64/laravel-boilerplate#contributors-and-supporters)
